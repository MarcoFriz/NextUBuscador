# NextUBuscador
Usado como tarea, su rol es filtrar una lista de casas y renderizarlas
